// th135arc.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include <windows.h>
#include <stdio.h>
#include <locale.h>
#include "TFPKArchive.h"
#include "tasofroCrypt.h"

void printUsage(wchar_t* myname)
{
	wprintf(L"Usage:\n"
		L"  %s </p|/x|/h> <Target>\n"
		L"  eg. %s /x th135.pak\n"
		L"        will eXtract all files in th135.pak to th135\\.\n"
		L"      %s /p th135\n"
		L"        will Pack all files in th135\\ into th135.pak.\n"
		L"      %s /h th135.exe\n"
		L"        will patch the public key in th135.exe", myname, myname, myname, myname);
	return;
}

int unused_wmain(int argc, wchar_t* argv[])
{
	setlocale(LC_ALL,"");

	wprintf(L"Archiver  for Touhou 13.5(HM)\n"
		    L"           By Riatre @ 201305\n"
		    L"\n"
		    //"This binary is for test purpose only. Do NOT distribute.\n\n"
		    );
	if(LoadDirNameList(L"dirlist.txt") == -1)
	{
		wprintf(L"[-] WARNING: dirlist.txt not found, path guessing disabled.\n\n");
	}
	if(argc < 3)
	{
		printUsage(argv[0]);
		return 0;
	}
	else
	{
		if(wcsicmp(argv[1],L"/x") == 0 || wcsicmp(argv[1],L"-x") == 0)
		{
			for(int i = 2;i < argc;i++)
			{
				wchar_t OutputDirectory[MAX_PATH] = {0};
				wcscpy(OutputDirectory,argv[i]);
				wchar_t* ext = wcsrchr(OutputDirectory,L'.');
				if(ext) *ext = 0;
				else wcscat(OutputDirectory,L"_eXtracted");

				wprintf(L"Extracting %s",argv[i]);
				ExtractAll(argv[i],OutputDirectory);
				wprintf(L"Finished.\n\n");
			}
		}
		else if(wcsicmp(argv[1],L"/p") == 0 || wcsicmp(argv[1],L"-p") == 0)
		{
			for(int i = 2;i < argc;i++)
			{
				wchar_t OutputFileName[MAX_PATH] = {0};
				wcscpy(OutputFileName,argv[i]);
				wcscat(OutputFileName,L".pak");

				wprintf(L"Packing %s\n",OutputFileName);
				BuildArchive(OutputFileName,argv[i]);
				wprintf(L"Finished.\n\n");
			}
		}
		else if(wcsicmp(argv[1],L"/h") == 0 || wcsicmp(argv[1],L"-h") == 0)
		{
			wprintf(L"Gonna patching PKPAIR\n");
			PatchBinary(argv[2]);
			wprintf(L"Done.\n");
		}
		else printUsage(argv[0]);
	}
	return 0;
}
