import os,sys,zlib,struct
import Image

fmt = '=5sBIIII'

def toPNG(stream,savename):
	fmtsize = struct.calcsize(fmt)

	if len(stream) < fmtsize:
		raise IOError(sys.argv[2] + ' : Invalid TFBM File. (File size mismatch)')

	magic,bits,width,height,padding_width,compSize = struct.unpack(fmt,stream[:fmtsize])

	if magic != 'TFBM\0' or compSize != len(stream)-fmtsize:
		raise IOError(sys.argv[2] + ' : Invalid TFBM File. (Invalid header)')

	if bits == 8:
		raise NotImplementedError(sys.argv[2] + ' : Unsupported Format: 8-bit with palette')
	if bits == 16:
		raise NotImplementedError(sys.argv[2] + ' : Unsupported Format: ARGB5551')
	if bits == 24:
		raise NotImplementedError(sys.argv[2] + ' : Unsupported Format: 24-bit bitmap')

	decomp = zlib.decompress(stream[fmtsize:])

	pixel_mode = ''
	if bits == 32: pixel_mode = 'BGRA'
	if bits == 24: pixel_mode = 'BGR'

	Image.fromstring("RGBA",(padding_width,height),decomp,"raw",pixel_mode,0,1).save(savename,"PNG")
	if padding_width != width:
		with open(savename+'_width.txt','wt') as fp:
			fp.write(str(width))

def fromPNG(pngfile):
	im = Image.open(pngfile)
	if os.path.exists(pngfile + '_width.txt'):
		with open(pngfile + '_width.txt','rt') as fp:
			width = int(fp.read())
		os.remove(pngfile+'_width.txt')
	else:
		width = im.size[0]
	stream = im.tostring("raw","BGRA")
	stream = zlib.compress(stream)
	header = struct.pack(fmt,'TFBM\0',32,width,im.size[1],im.size[0],len(stream))
	return header + stream

if __name__ == '__main__':
	print '       TFBMTool for TH13.5(HM)'
	print '                                  By Riatre'
	print 'Currently only 32bit pictures are supported, \n\
	       most of them has the extension ".png".'
	if len(sys.argv) < 4:
		print 'Usage: TFBMTool.py </d|/w> <TFBM file> <png file>'
		sys.exit(0)

	if sys.argv[1] == '/d' or sys.argv[1] == '-d':
		with open(sys.argv[2],'rb') as fp: 
			cont = fp.read()
		toPNG(cont,sys.argv[3])

		print '%s to %s, Done!' % (sys.argv[2],sys.argv[3])

	if sys.argv[1] == '/w' or sys.argv[1] == '-w':
		data = fromPNG(sys.argv[3])
		with open(sys.argv[2],'wb') as fp: 
			fp.write(data)

		print '%s to %s, Done!' % (sys.argv[3],sys.argv[2])
