#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <time.h>
#include <unordered_map>
#include <list>
#include <forward_list>
#include <random>
#include <ctype.h>

#include "tasofroCrypt.h"
#include "TFPKArchive.h"
#include "zlib.h"

BOOL CreateDirectoryForPath(wchar_t* Path)
{
	BOOL result = FALSE;
	unsigned int length = wcslen(Path);
	for (unsigned int i = 0; i < length; i++)
	{
		if (Path[i] == L'\\' || Path[i] == L'/')
		{
			Path[i] = 0;
			result = CreateDirectory(Path, NULL);
			Path[i] = L'\\';
		}
	}
	return result;
}

// Normalized Hash
DWORD SpecialFNVHash(char *begin, char *end, DWORD initHash = 0x811C9DC5u)
{
	DWORD hash; // eax@1
	DWORD ch; // esi@2

	int inMBCS = 0;
	for (hash = initHash; begin != end; hash = ch ^ 0x1000193 * hash)
	{
		ch = *begin++;
		if (!inMBCS && ((unsigned char)ch >= 0x81u && (unsigned char)ch <= 0x9Fu || (unsigned char)ch + 32 <= 0x1Fu)) inMBCS = 2;
		if (!inMBCS)
		{
			ch = tolower(ch);  // bad ass style but WORKS PERFECTLY!
			if (ch == '/') ch = '\\';
		}
		else inMBCS--;
	}
	return hash;
}

std::unordered_map<DWORD, std::string> dirHashToName;
int LoadDirNameList(wchar_t* FileName)
{
	FILE* fp = _wfopen(FileName, L"rt");
	if (!fp) return -1;
	char DirName[MAX_PATH] = { 0 };
	while (fgets(DirName, MAX_PATH, fp))
	{
		int tlen = strlen(DirName);
		while (tlen && DirName[tlen - 1] == '\n') DirName[--tlen] = 0;
		DWORD thash = SpecialFNVHash(DirName, DirName + tlen);
		dirHashToName[thash] = DirName;
	}
	fclose(fp);
	return 0;
}

int CryptBlock(BYTE* Data, DWORD FileSize, DWORD* Key)
{
	for (int j = 0; j < FileSize / 4; j++)
	{
		*((DWORD*)Data + j) ^= Key[j % 4];
	}

	int remain = FileSize % 4;
	if (remain)
	{
		DWORD tk = Key[FileSize / 4 % 4];
		for (int j = 0; j < remain; j++)
		{
			Data[FileSize - remain + j] ^= tk & 0xFF;
			tk >>= 8;
		}
	}
	return 0;
}

int ExtractAll(const wchar_t* ArchiveFileName, const wchar_t* OutputFolder)
{
	HANDLE hFile = CreateFile(ArchiveFileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_RANDOM_ACCESS, NULL);
	HANDLE hInMapping = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, GetFileSize(hFile, NULL), NULL);
	BYTE* pPackage = (BYTE*)MapViewOfFile(hInMapping, FILE_MAP_READ, 0, 0, 0);
	if (hFile == INVALID_HANDLE_VALUE || hInMapping == INVALID_HANDLE_VALUE || !pPackage)
		return 0;

	DWORD Magic = *(DWORD*)pPackage;
	if (Magic != 'KPFT')
		return 0;

	DWORD cur = 5;
	DWORD DirCount = 0;
	Decrypt6432(pPackage + cur, (BYTE*)&DirCount, sizeof(DWORD));
	cur += KEY_BYTESIZE;
	DIRLIST* DirList = new DIRLIST[DirCount];
	ZeroMemory(DirList, DirCount*sizeof(DIRLIST));
	for (int i = 0; i < DirCount; i++)
	{
		Decrypt6432(pPackage + cur, (BYTE*)&DirList[i], sizeof(DWORD) * 2);
		if (dirHashToName.find(DirList[i].PathHash) != dirHashToName.end())
			swprintf(DirList[i].Path, L"%S", dirHashToName[DirList[i].PathHash].c_str());
		else
			swprintf(DirList[i].Path, L"UNK_%08X\\", DirList[i].PathHash);
		cur += KEY_BYTESIZE;
	}

	FNHEADER fnh;
	ZeroMemory(&fnh, sizeof(FNHEADER));
	Decrypt6432(pPackage + cur, (BYTE*)&fnh, sizeof(FNHEADER));
	cur += KEY_BYTESIZE;
	BYTE* CompFN = new BYTE[fnh.CompSize + KEY_BYTESIZE];
	for (int i = 0; i < fnh.BlockCnt; i++)
	{
		Decrypt6432(pPackage + cur, CompFN + i*KEY_BYTESIZE / 2);
		cur += KEY_BYTESIZE;
	}
	char* FNList = new char[fnh.OrigSize];
	DWORD realOrigSize = fnh.OrigSize;
	ZeroMemory(FNList, fnh.OrigSize);
	uncompress((BYTE*)FNList, &realOrigSize, CompFN, fnh.CompSize);
	delete[] CompFN;
	//HANDLE hTemp = CreateFile(L"fnlist.txt",GENERIC_READ|GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_FLAG_RANDOM_ACCESS,NULL);
	//WriteFile(hTemp,FNList,fnh.OrigSize,&realOrigSize,NULL);
	//CloseHandle(hTemp);
	assert(fnh.OrigSize == realOrigSize);

	// assign file hash <-> file name lookup table
	std::unordered_map<DWORD, std::pair<wchar_t*, char*> > hashToName;
	DWORD fnPos = 0;
	for (int i = 0; i < DirCount; i++)
	{
		for (int j = 0; j < DirList[i].FileCount; j++)
		{
			int tlen = strlen(FNList + fnPos);
			DWORD NameHash = SpecialFNVHash(FNList + fnPos, FNList + fnPos + tlen, DirList[i].PathHash);
			hashToName[NameHash] = std::make_pair(DirList[i].Path, FNList + fnPos);
			fnPos += tlen + 1;
		}
	}

	LISTHEADER lh;
	ZeroMemory(&lh, sizeof(LISTHEADER));
	Decrypt6432(pPackage + cur, (BYTE*)&lh, sizeof(LISTHEADER));
	cur += KEY_BYTESIZE;

	TFPKLIST* FileList = new TFPKLIST[lh.FileCount];
	ZeroMemory(FileList, sizeof(TFPKLIST)*lh.FileCount);
	for (int i = 0; i < lh.FileCount; i++)
	{
		LISTITEM li;
		Decrypt6432(pPackage + cur, (BYTE*)&li, sizeof(LISTITEM));
		cur += KEY_BYTESIZE;
		Decrypt6432(pPackage + cur, (BYTE*)&FileList[i].NameHash, sizeof(DWORD));
		cur += KEY_BYTESIZE;
		Decrypt6432(pPackage + cur, (BYTE*)FileList[i].Key, sizeof(DWORD) * 4);
		cur += KEY_BYTESIZE;

		FileList[i].Offset = li.Offset;
		FileList[i].FileSize = li.FileSize;

		std::pair<wchar_t*, char*> hpair = hashToName[FileList[i].NameHash];
		FileList[i].Path = hpair.first;
		FileList[i].FileName = hpair.second;
	}

	assert(hashToName.size() == lh.FileCount);

	DWORD FileBeginOffset = cur;

	for (int i = 0; i < lh.FileCount; i++)
	{
		BYTE* Data = new BYTE[FileList[i].FileSize + 100];
		memcpy(Data, pPackage + FileBeginOffset + FileList[i].Offset, FileList[i].FileSize);
		CryptBlock(Data, FileList[i].FileSize, FileList[i].Key);

		wchar_t PathName[MAX_PATH] = { 0 };
		swprintf(PathName, L"%s\\%s\\%S", OutputFolder, FileList[i].Path, FileList[i].FileName);
		CreateDirectoryForPath(PathName);
		HANDLE hOutFile = CreateFile(PathName, GENERIC_READ | GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_FLAG_RANDOM_ACCESS, NULL);
		HANDLE hMapping = CreateFileMapping(hOutFile, NULL, PAGE_READWRITE, 0, FileList[i].FileSize, NULL);
		BYTE* pFile = (BYTE*)MapViewOfFile(hMapping, FILE_MAP_READ | FILE_MAP_WRITE, 0, 0, 0);
		if (!pFile || hMapping == INVALID_HANDLE_VALUE || hOutFile == INVALID_HANDLE_VALUE)
		{
			CloseHandle(hMapping);
			CloseHandle(hOutFile);
			if (FileList[i].FileSize != 0)
			{
				printf("!");
			}
			continue;
		}
		memcpy(pFile, Data, FileList[i].FileSize);
		delete[] Data;

		UnmapViewOfFile(pFile);
		CloseHandle(hMapping);
		CloseHandle(hOutFile);

		printf(".");
	}

	delete[] FNList;
	delete[] FileList;

	UnmapViewOfFile(pPackage);
	CloseHandle(hInMapping);
	CloseHandle(hFile);

	return 1;
}

int BuildList(const wchar_t* Path, std::forward_list<TFPKLIST>& FileList, std::forward_list<DIRLIST>& DirList, std::forward_list<char*>& FNList, DWORD ArcPathHash = 0x811C9DC5u)
{
	wchar_t FindPath[MAX_PATH] = { 0 };
	HANDLE hFind = INVALID_HANDLE_VALUE;
	WIN32_FIND_DATA FindData = { 0 };

	swprintf(FindPath, L"%s\\*.*", Path);
	hFind = FindFirstFile(FindPath, &FindData);
	if (hFind == INVALID_HANDLE_VALUE) return -1;

	std::forward_list<char*> thisFN;
	int FileCount = 0;
	do
	{
		if (wcscmp(FindData.cFileName, L".") == 0 || wcscmp(FindData.cFileName, L"..") == 0) continue;

		if (FindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		{
			wchar_t NPath[MAX_PATH] = { 0 };
			swprintf(NPath, L"%s\\%s", Path, FindData.cFileName);

			DWORD naph = 0;
			if (wcsncmp(FindData.cFileName, L"UNK_", 4) != 0)
			{
				char TLoc[MAX_PATH] = { 0 };
				sprintf(TLoc, "%S\\", FindData.cFileName);
				int len = strlen(TLoc);
				naph = SpecialFNVHash(TLoc, TLoc + len, ArcPathHash);
			}
			else swscanf(FindData.cFileName, L"UNK_%08X", &naph);
			BuildList(NPath, FileList, DirList, FNList, naph);
		}
		else
		{
			FileCount++;
			wchar_t* PathName = new wchar_t[MAX_PATH];
			swprintf(PathName, L"%s\\%s", Path, FindData.cFileName);

			char* FName = new char[MAX_PATH];
			sprintf(FName, "%S", FindData.cFileName);
			int len = strlen(FName);
			TFPKLIST item;
			memset(&item, 0, sizeof(TFPKLIST));
			item.Path = PathName;
			item.NameHash = SpecialFNVHash(FName, FName + len, ArcPathHash);
			FileList.push_front(item);
			thisFN.push_front(FName);
		}
	} while (FindNextFile(hFind, &FindData));

	DIRLIST tdl;
	tdl.FileCount = FileCount;
	tdl.PathHash = ArcPathHash;
	DirList.push_front(tdl);
	FNList.splice_after(FNList.before_begin(), thisFN);
	return 0;
}

int BuildArchive(const wchar_t* ArchiveFileName, const wchar_t* InputFolder)
{
	std::forward_list<TFPKLIST> FileList;
	std::forward_list<DIRLIST> DirList;
	std::forward_list<char*> FNList;
	wprintf(L"Scanning files...");
	BuildList(InputFolder, FileList, DirList, FNList);
	wprintf(L"Done.\nCalculating necessary metainfo...");

	DWORD DirCount = 0;
	for (auto& it : DirList) DirCount++;

	FNHEADER fnh;
	memset(&fnh, 0, sizeof(FNHEADER));
	for (auto& it : FNList)
	{
		fnh.OrigSize += strlen(it) + 1;
	}
	char* OrigFN = new char[fnh.OrigSize];
	memset(OrigFN, 0, fnh.OrigSize);
	int pos = 0;
	for (auto& it : FNList)
	{
		strcat(OrigFN + pos, it);
		pos += strlen(it) + 1;
	}
	fnh.CompSize = compressBound(fnh.OrigSize);
	fnh.CompSize += 0x20 - fnh.CompSize % 0x20;
	unsigned char* CompFN = new unsigned char[fnh.CompSize];
	compress(CompFN, &fnh.CompSize, (BYTE*)OrigFN, fnh.OrigSize);
	fnh.BlockCnt = (fnh.CompSize / 0x20) + (fnh.CompSize % 0x20 != 0);

	std::mt19937 rng(time(NULL));
	DWORD Offset = 0;
	LISTHEADER lh;
	memset(&lh, 0, sizeof(LISTHEADER));
	for (auto& it : FileList)
	{
		lh.FileCount++;
		for (int i = 0; i < 4; i++) it.Key[i] = rng();
		it.Offset = Offset;

		HANDLE hFile = CreateFile(it.Path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
		it.FileSize = GetFileSize(hFile, NULL);
		CloseHandle(hFile);
		Offset += it.FileSize;
	}

	DWORD PackageSize = 5 + (1 + DirCount)*KEY_BYTESIZE + (1 + fnh.BlockCnt)*KEY_BYTESIZE + (1 + lh.FileCount * 3)*KEY_BYTESIZE + Offset;
	wprintf(L"Done!\nWill generate a package file with %d folders and %d files.\n", DirCount, lh.FileCount);
	wprintf(L"Generating encrypted file list...");

	HANDLE hOutFile = CreateFile(ArchiveFileName, GENERIC_WRITE | GENERIC_READ, FILE_SHARE_WRITE | FILE_SHARE_READ, NULL, CREATE_ALWAYS, 0, NULL);
	HANDLE hFileMapping = CreateFileMapping(hOutFile, NULL, PAGE_READWRITE, 0, PackageSize, NULL);
	BYTE* pPackage = (BYTE*)MapViewOfFile(hFileMapping, FILE_MAP_READ | FILE_MAP_WRITE, 0, 0, PackageSize);

	*(DWORD*)pPackage = 'KPFT'; // Magic
	DWORD cur = 5;
	Encrypt3264((BYTE*)&DirCount, pPackage + cur, sizeof(DWORD)); cur += KEY_BYTESIZE;
	for (auto it : DirList)
	{
		Encrypt3264((BYTE*)&it, pPackage + cur, sizeof(DWORD) * 2); cur += KEY_BYTESIZE;
	}
	Encrypt3264((BYTE*)&fnh, pPackage + cur, sizeof(FNHEADER)); cur += KEY_BYTESIZE;
	for (int i = 0; i < fnh.BlockCnt; i++)
	{
		Encrypt3264(CompFN + i * 0x20, pPackage + cur); cur += KEY_BYTESIZE;
	}
	Encrypt3264((BYTE*)&lh, pPackage + cur, sizeof(LISTHEADER)); cur += KEY_BYTESIZE;
	for (auto& it : FileList)
	{
		LISTITEM li;
		li.Offset = it.Offset; li.FileSize = it.FileSize;
		Encrypt3264((BYTE*)&li, pPackage + cur, sizeof(LISTITEM)); cur += KEY_BYTESIZE;

		Encrypt3264((BYTE*)&it.NameHash, pPackage + cur, sizeof(DWORD)); cur += KEY_BYTESIZE;
		Encrypt3264((BYTE*)&it.Key, pPackage + cur, sizeof(it.Key)); cur += KEY_BYTESIZE;
	}
	wprintf(L"Done.\nCopying files");
	for (auto& it : FileList)
	{
		DWORD ReadBytes = 0;
		HANDLE hIn = CreateFile(it.Path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
		ReadFile(hIn, pPackage + cur, it.FileSize, &ReadBytes, NULL);
		CloseHandle(hIn);

		CryptBlock(pPackage + cur, it.FileSize, it.Key);
		cur += it.FileSize;
		wprintf(L".");
	}

	UnmapViewOfFile(pPackage);
	CloseHandle(hFileMapping);
	CloseHandle(hOutFile);
	return 1;
}
