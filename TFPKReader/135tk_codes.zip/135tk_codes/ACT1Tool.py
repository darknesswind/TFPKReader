#!/usr/bin/env python
# coding=utf8

import os,sys,re,struct,io,traceback
import json,pprint,hashlib

def unpack_from_stream(stream,fmt):
	fmtsize = struct.calcsize(fmt)
	return struct.unpack(fmt,stream.read(fmtsize))

def pack_to_stream(stream,fmt,*args):
	try:
		return stream.write(struct.pack(fmt,*args))
	except:
		print fmt,args
		sys.exit(0)

def read_int(stream):
	r, = unpack_from_stream(stream,'=i')
	return r
def read_float(stream):
	f, = unpack_from_stream(stream,'=f')
	return f
def read_bool(stream):
	b, = unpack_from_stream(stream,'=?')
	return b
def read_byte(stream):
	b, = unpack_from_stream(stream,'=B')
	return b
def read_string(stream):
	size, = unpack_from_stream(stream,'=I')
	s, = unpack_from_stream(stream,'=%ds'%size)
	return s
def read_wtf(stream):
	cnt = read_int(stream)
	return cnt
def read_array1d(stream):
	ele, = unpack_from_stream(stream,'=I')
	arr = []
	for i in xrange(ele): arr += [read_byte(stream)]
	return arr
def read_array2d(stream):
	n,m = unpack_from_stream(stream,'=II')
	arr = []
	for i in xrange(n):
		tarr = []
		for j in xrange(m):
			tarr += [read_byte(stream)]
		arr += [tarr]
	return arr

def write_int(stream,val): return pack_to_stream(stream,'=i',val)
def write_float(stream,val): return pack_to_stream(stream,'=f',val)
def write_bool(stream,val): return pack_to_stream(stream,'=?',val)
def write_byte(stream,val): return pack_to_stream(stream,'=B',val)
def write_string(stream,val):
	slen = len(val)
	return pack_to_stream(stream,'=I%ds'%slen,slen,val)
def write_wtf(stream,val): return write_int(stream,val)
def write_array1d(stream,lst):
	ele = len(lst)
	size = pack_to_stream(stream,'=I',ele)
	for i in lst: size += write_byte(stream,i)
	return size
def write_array2d(stream,lst):
	n,m = len(lst),0
	if n > 0: m = len(lst[0])
	size = pack_to_stream(stream,'=II',n,m)
	for i in lst:
		for j in i:
			size += write_byte(stream,j)
	return size

def read_table(stream,magic,pre_type=None,pre_name=None):
	hint, = unpack_from_stream(stream,'=?')

	var_name = []
	var_type = []
	var_value = []
	if hint:
		col, = unpack_from_stream(stream,"=i")
		for j in xrange(col):
			var_name += [read_string(stream)]
			var_type += [read_int(stream)]

		# *** CODE FOR GENERATING TYPE TABLE *** 
		#MAGIC_TABLE_TYPE[magic] += [var_type]
		#MAGIC_TABLE_NAME[magic] += [var_name]
	else:
		var_type = pre_type
		var_name = pre_name
		col = len(var_type)

	for j in xrange(col):
		var_value += [type_reader[var_type[j]](stream)]

	if magic == 0xA597329B:
		for j in xrange(col):
			if var_type[j] == TYPE_WTF:
				tl = []
				for p in xrange(var_value[j]): tl += [read_int(stream)]
				var_value[j] = (var_value[j],tl)

	result = []
	for j in xrange(col):
		result.append((type_name[var_type[j]],var_name[j],var_value[j]))
	return result
def write_table(stream,tbl,magic):
	hint,col = True,len(tbl)
	size = pack_to_stream(stream,'=?',hint)

	if hint:
		size += pack_to_stream(stream,'=i',col)
		for j in tbl:
			size += write_string(stream,j[1])
			size += write_int(stream,name_to_type[j[0]])

	for j in tbl:
		p = j[2]
		if magic == 0xA597329B and name_to_type[j[0]] == TYPE_WTF: p = p[0]
		size += type_writer[name_to_type[j[0]]](stream,p)

	if magic == 0xA597329B:
		for j in tbl:
			if name_to_type[j[0]] == TYPE_WTF:
				for cv in j[2][1]:
					size += write_int(stream,cv)
	return size

def read_st1(stream):
	cnt = read_int(stream)
	result = []
	for i in xrange(cnt):
		magic, = unpack_from_stream(stream,'=I')
		if magic not in MAGIC_TO_STRUCT:
			raise SyntaxError('Read ST1 Found an unknown magic: %08X' % magic)
		result.append((magic,read_certain_struct(stream,magic)))
	return result
def read_st2(stream):
	cnt = read_byte(stream)
	result = []
	for i in xrange(cnt):
		magic, = unpack_from_stream(stream,'=I')
		if magic not in MAGIC_TO_STRUCT:
			raise SyntaxError('Read ST2 Found an unknown magic: %08X' % magic)
		result.append((magic,read_certain_struct(stream,magic)))
	return result

def write_st1(stream,stbl):
	cnt = len(stbl)
	size = write_int(stream,cnt)
	for i in stbl:
		magic = i[0]
		size += pack_to_stream(stream,'=I',magic) # magic
		if magic not in MAGIC_TO_STRUCT:
			raise SyntaxError('Write ST1 Found an unknown magic: %08X' % magic)
		size += write_certain_struct(stream,magic,i[1])
	return size
def write_st2(stream,stbl):
	cnt = len(stbl)
	size = write_byte(stream,cnt)
	for i in stbl:
		magic = i[0]
		size += pack_to_stream(stream,'=I',magic) # magic
		if magic not in MAGIC_TO_STRUCT:
			raise SyntaxError('Write ST2 Found an unknown magic: %08X' % magic)
		size += write_certain_struct(stream,magic,i[1])
	return size

TYPE_INT = 0
TYPE_FLOAT = 1
TYPE_BOOL = 2
TYPE_STRING = 3
TYPE_WTF = 5 # it may be array but 
TYPE_TABLE = 1000
TYPE_SUBTABLE1 = 1001
TYPE_SUBTABLE2 = 1002
TYPE_ARR1D = 1003
TYPE_ARR2D = 1004

type_reader = {
	0: read_int, 1: read_float, 2: read_bool, 3: read_string, 5: read_wtf, TYPE_TABLE: read_table, TYPE_SUBTABLE1: read_st1, TYPE_SUBTABLE2: read_st2,
	TYPE_ARR2D: read_array2d, TYPE_ARR1D: read_array1d
}
type_writer = {
	0: write_int, 1: write_float, 2: write_bool, 3: write_string, 5: write_wtf, TYPE_TABLE: write_table, TYPE_SUBTABLE1: write_st1, TYPE_SUBTABLE2: write_st2,
	TYPE_ARR2D: write_array2d, TYPE_ARR1D: write_array1d
}
type_name = {0: "int", 1: "float", 2: "bool", 3: "string", 5: "wtf"}
name_to_type = {type_name[i]:i for i in type_name.keys()}

MAGIC_TABLE_TYPE = {
0x44C0E960: [[0, 0, 0, 1, 1, 1, 1, 3, 3]], 
0x8CB4D3C0: [[0, 0, 0, 1, 1, 1, 1, 3, 3]], 
0x79890bb2: [[2, 1, 1, 1, 2, 0, 1, 1, 1, 0, 1, 1, 1, 0, 3, 2, 2], [2, 3]], 
0xECD7EF7B: [[3]], 
0xbcd50c74: [[1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0]], 
0x16cd8498: [[0, 0, 1, 1, 1, 0, 3]], 
0xbbb44db9: [[1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 2]], 
0x9edd843a: [[0, 0, 0, 1, 1, 1, 1, 3, 3], [5, 5, 0, 0, 0, 1, 1, 1, 1, 3, 3]], 
0xa597329b: [[2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 2, 2, 0, 0, 0, 1, 1, 1, 1, 2, 3, 3, 3, 2, 0, 2, 0]], 
0xdeadbeef: [[2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 3, 0, 2, 2], [2, 3]]}
MAGIC_TABLE_NAME = {
0x44C0E960: [['image_height', 'image_width', 'resourceID', 'src_height', 'src_width', 'src_x', 'src_y', 'stName', 'stTextureName']], 
0x8CB4D3C0: [['image_height', 'image_width', 'resourceID', 'src_height', 'src_width', 'src_x', 'src_y', 'stName', 'stTextureName']], 
0x79890bb2: [['debugOnly', 'dst_x', 'dst_y', 'dst_z', 'expand', 'layerID', 'ox', 'oy', 'oz', 'parentID', 'prev_x', 'prev_y', 'prev_z', 'resourceID', 'stName', 'useKeyTimeline', 'visible'], ['compiled', 'filePath']], 
0xECD7EF7B: [['st_layout_name']], 
0xbcd50c74: [['alpha', 'blend', 'colorB', 'colorG', 'colorR', 'cor_x', 'cor_y', 'cor_z', 'cos_x', 'cos_y', 'cos_z', 'roll.x', 'roll.y', 'roll.z', 'scale.x', 'scale.y', 'scale.z', 'textureFilter']], 
0x16cd8498: [['activeLength', 'beginFrame', 'layerX', 'layerY', 'layerZ', 'resourceID', 'scriptFunction']], 
0xbbb44db9: [['alpha', 'blend', 'colorB', 'colorG', 'colorR', 'cor_x', 'cor_y', 'cor_z', 'cos_x', 'cos_y', 'cos_z', 'roll.x', 'roll.y', 'roll.z', 'scale.x', 'scale.y', 'scale.z', 'textureFilter', 'use_rhw']], 
0x9edd843a: [['image_height', 'image_width', 'resourceID', 'src_height', 'src_width', 'src_x', 'src_y', 'stName', 'stTextureName'], ['default_font_height', 'default_font_width', 'image_height', 'image_width', 'resourceID', 'src_height', 'src_width', 'src_x', 'src_y', 'stName', 'stTextureName']], 
0xa597329b: [['addEdge', 'alignment', 'alpha', 'baseB', 'baseG', 'baseR', 'blend', 'charactorSpace', 'colorB', 'colorB2', 'colorG', 'colorG2', 'colorR', 'colorR2', 'edgeB', 'edgeG', 'edgeR', 'fontHeight', 'fontWeight', 'font_count', 'lineSpace', 'plotCharPerFrame', 'plotSliceTime', 'priorDefaultFont', 'ruby_edge', 'ruby_offset', 'ruby_size', 'ruby_weight', 'scaleX', 'scaleY', 'shadowOffsetX', 'shadowOffsetY', 'sharpEdge', 'stBackQueue', 'stFontFaceName', 'stText', 'useShadow', 'v_alignment', 'vertical', 'wordBreakWidth']], 
0xdeadbeef: [['autostart', 'canvasA', 'canvasB', 'canvasG', 'canvasR', 'loop', 'marginBottom', 'marginLeft', 'marginRight', 'marginTop', 'offsetX', 'offsetY', 'resolutionMs', 'screenHeight', 'screenWidth', 'stName', 'templateLayerID', 'use_external_script', 'visible'], ['compiled', 'filePath']]}


MAGIC_TO_STRUCT = {
	0xDEADBEEF : [TYPE_TABLE,TYPE_TABLE,TYPE_STRING], # .global.nut 

	0x79890BB2 : [TYPE_TABLE,TYPE_SUBTABLE1,TYPE_SUBTABLE1,TYPE_TABLE,TYPE_STRING],   # Layer
	0x16CD8498 : [TYPE_TABLE,TYPE_SUBTABLE2],  # KeyFrame
	# Combined with types above
	0xA597329B : [TYPE_TABLE],  # StringLayout
	0xBCD50C74 : [TYPE_TABLE],  # SpriteLayout
	0xBBB44DB9 : [TYPE_TABLE],  # IFSMeshLayout
	0xECD7EF7B : [TYPE_TABLE],  # ReservedLayout  // ... 我靠。。。

	# 	
	0x44C0E960 : [TYPE_TABLE], # ImageResource
	0x9EDD843A : [TYPE_TABLE,TYPE_TABLE,TYPE_ARR2D],  # BitmapFontResource
	0x8CB4D3C0 : [TYPE_TABLE],
}

def read_certain_struct(stream,magic):
	pos = 0
	stru = MAGIC_TO_STRUCT[magic]
	result = []
	# *** CODE FOR GENERATING TYPE TABLE *** 
	#MAGIC_TABLE_TYPE[magic] = []
	#MAGIC_TABLE_NAME[magic] = []
	for i in stru:
		if i is TYPE_TABLE:
			result += [type_reader[i](stream,magic,MAGIC_TABLE_TYPE[magic][pos],MAGIC_TABLE_NAME[magic][pos])]
			#result += [type_reader[i](stream,magic)] # *** CODE FOR GENERATING TYPE TABLE *** 
			pos += 1
		else:
			result += [type_reader[i](stream)]
	return result
def write_certain_struct(stream,magic,data):
	stru = MAGIC_TO_STRUCT[magic]
	size = 0
	pos = 0
	for i in xrange(len(stru)):
		if stru[i] is TYPE_TABLE:
			size += type_writer[stru[i]](stream,data[i],magic)
			pos += 1
		else:
			size += type_writer[stru[i]](stream,data[i])
	return size

def read_act_file(data):
	global GLOBAL_UNKBEHAVIOUR
	GLOBAL_UNKBEHAVIOUR = 0
	stream = io.BytesIO(data)
	try:
		header,p1cnt = unpack_from_stream(stream,'=4si')
		if header != 'ACT1': raise IOError('Not an ACT file.')

		base_script = []
		for i in xrange(p1cnt):
			magic, = unpack_from_stream(stream,'=I')
			base_script.append((magic,read_certain_struct(stream,0xDEADBEEF)))

		layout_info = 	(stream)

		resource_info = read_st1(stream)

		if len(stream.read()) > 0: raise SyntaxError('Unrecognized data remaining..')

		return base_script,layout_info,resource_info
	except:
		with open('dump.bin','wb') as dump: dump.write(stream.read())
		traceback.print_exc()
		sys.exit(0)
def write_act_file(data):
	if len(data) != 3: raise IOError('Invalid Raw Data')
	global GLOBAL_UNKBEHAVIOUR
	GLOBAL_UNKBEHAVIOUR = 0
	stream = io.BytesIO()
	try:
		header,p1cnt,p2cnt,p3cnt = 'ACT1',len(data[0]),len(data[1]),len(data[2])
		pack_to_stream(stream,'=4sI',header,p1cnt)
		for i in data[0]:
			pack_to_stream(stream,'=I',i[0]) # magic
			write_certain_struct(stream,0xDEADBEEF,i[1])

		write_st1(stream,data[1]) # layout_info

		write_st1(stream,data[2]) # resource_info

		return stream.getvalue()
	except:
		traceback.print_exc()
		sys.exit(0)

def export_external(object,name_base):
	typ = type(object)
	if typ is list:
		for i in xrange(len(object)):
			if type(object[i]) is str and object[i].startswith('\xFA\xFARIQS'):
				data = object[i]
				file_name = '_' + hashlib.sha1(data).hexdigest() + '.nut'
				object[i] = '@external ' + file_name
				with open(name_base + file_name,'wb') as fp: fp.write(data)

	if typ is list or typ is tuple:
		for i in object:
			export_external(i,name_base)

def import_external(object,name_base,clean):
	typ = type(object)
	if typ is list:
		for i in xrange(len(object)):
			if type(object[i]) is str and object[i].startswith('@external '):
				file_name = object[i][10:]
				with open(name_base + file_name,'rb') as fp: data = fp.read()
				object[i] = data
				if clean: os.remove(name_base + file_name)

	if typ is list or typ is tuple:
		for i in object:
			import_external(i,name_base,clean)

if __name__ == '__main__':
	print '       ACT1Tool for TH135(HM)     '
	print '                         By Riatre'
	print ' BTW, What is libact?'
	if len(sys.argv) < 4:
		print 'Usage:'
		print '  ACT1Tool.py </d|/w> <act file> <text dump> [/clean]'
		print '   /clean option is broken, do NOT use!'
		#print '  If /clean option specified, all external nuts file will be deleted.'
		sys.exit(0)

	op = sys.argv[1]
	act = sys.argv[2]
	dmp = sys.argv[3]
	#clean = len(sys.argv) > 4 and (sys.argv[4] == '/clean' or sys.argv[4] == '-clean')
	clean = False
	if op == '-d' or op == '/d':
		with open(act,'rb') as fp: data = fp.read()
		result = read_act_file(data)
		export_external(result,dmp)
		with open(dmp,'wt') as fp: pprint.pprint(result,indent=1,width=160,stream=fp)
		# *** CODE FOR GENERATING TYPE TABLE *** 
		#print MAGIC_TABLE_TYPE
		#print MAGIC_TABLE_NAME
	elif op == '-w' or op == '/w':
		with open(dmp,'rt') as fp: data = eval(fp.read().replace('\x00','\\x00')) # dirty dirty hack
		import_external(data,dmp,clean)
		result = write_act_file(data)
		with open(act,'wb') as fp: fp.write(result)
